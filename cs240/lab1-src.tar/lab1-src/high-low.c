#include <stdio.h>
//

int
main(int argc, char **argv) {
  printf("Welcome to the High Low game...\n");

  // Write your implementation here...

}

